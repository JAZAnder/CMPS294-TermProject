<?php 
//The MySQL server
$host = 'db';

// Database username
$user = 'MYSQL_USER';

//database user password
$pass = 'MYSQL_PASSWORD';

//SQL Database
$database = 'MYSQL_DATABASE';

$conn = new mysqli($host, $user, $pass, $database);
?>
